package griffith;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {

	private static ArrayList<Item> backpack = new ArrayList<>();
	private static final double MAX_WEIGHT = 50;

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		ArrayList<String> lines = new ArrayList<>();
		lines.add("today is monday");
		lines.add("yesterday was saturday.");
		lines.add("There is a month left");
		lines.add("  Where is he?  ");
		
		//with the arraylist i added i can easily array sentences.

		System.out.println("Task 1");
		System.out.println("Original sentences:");
		for (String sentence : lines) {
			System.out.println(sentence);
		}
		//bringing the method for printing
		fixed(lines);

		System.out.println("");
		System.out.println("Edited sentences:");
		for (String sentence : lines) {
			System.out.println(sentence);
		}
		System.out.println("");
		System.out.println("Task 2");
		//circle's information.
		Circle circleOne = new Circle(1.0, "Dark Blue");
		Circle circleTwo = new Circle(2.0, "Magenta");
		Circle circleThree = new Circle(3.0, "Pink");

		ArrayList<Circle> circles = new ArrayList<>();
		circles.add(circleOne);
		circles.add(circleTwo);
		circles.add(circleThree);
		//arraylist for circles
		
		circle(circles);
		//brings the circle method for printing reasons.
		System.out.println("");
		System.out.println("Task 3");

		boolean entry = false;
		//boolean for users if they want to quit or keep using the program.
		while (!entry) {
			System.out.println("Type 1 to give me a new item for my backpack.\n"
					+ "Type 2 if you want to take your item back.\n"
					+ "Type 3 if you want to take a look at my backpack.\n"
					+ "Type 4 if you want to end the dialogue.");
			String options = input.nextLine();
			switch (options) {
			//switch case was the best option for different scenarios.
			case "1":
				System.out.println("What is the name of the new item?");
				String name = input.nextLine();
				System.out.println("How heavy the item that you hold in kg");
				double weight = input.nextDouble();
				input.nextLine();
				//it is for consuming the newline character left in the input buffer by the previous method.
				Item item = new Item(name, weight);
				addItem(item);
				//printing the new item's method.
				break;
			case "2":
				System.out.println("Enter item name:");
				String itemName = input.nextLine();
				itemRemover(itemName);
				//printing the removed item's method.
				break;
			case "3":
				backpack();
				//showing my backpack to the user.
				break;
			case "4":
				entry = true;
				//asking to user if they want to end the dialogue.
				break;
			}
		}

	}

	public static void fixed(ArrayList<String> lines) {
		//method for grammatical help.
		for (int i = 0; i < lines.size(); i++) {
			String sentence = lines.get(i);
			sentence = sentence.trim(); 
			//removes extra whitespace at start or end
			char lastChar = sentence.charAt(sentence.length() - 1);
			if (lastChar > 'A' && lastChar < 'z'){
				sentence += ".";
				//sentence already ends with punctuation
			}
			sentence = sentence.substring(0, 1).toUpperCase() + sentence.substring(1); 
			// capitalizes the first letter of the sentence.
			lines.set(i, sentence);
		}
	}
	public static void circle(ArrayList<Circle> circles) {
		//method for circles.
		Circle largestCircle = circles.get(0);
		Circle smallestCircle = circles.get(0);
		//defining the smallest and the largest circle so the left circle will be the second largest.
		for (Circle circle : circles) {
			if (circle.area() > largestCircle.area()) {
				largestCircle = circle;
				//comparing the area between them to find the largest circle.
			}
			if (circle.area() < smallestCircle.area()) {
				smallestCircle = circle;
				//comparing the area between them to find the smallest circle.
			}
		}
		//printing
		if (largestCircle != smallestCircle) {
			System.out.println("The " + largestCircle.getColor() + " circle has the largest area");
			System.out.println("The " + smallestCircle.getColor() + " circle has the smallest area");
			for (Circle circle : circles) {
				if (circle != largestCircle && circle != smallestCircle) {
					System.out.println("The " + circle.getColor() + " circle has the second largest area");
				}
			}
		} 
	}
	public static double weightCalculator() {
		//method for calculating the weight.
		double weight = 0;
		for (Item item : backpack) {
			weight += item.getWeight();
		}
		return weight;
	}

	public static void addItem(Item item) {
		if (weightCalculator() + item.getWeight() > MAX_WEIGHT) {
			System.out.println("Dude I can't carry that much!!");
			//letting the user know how weak i am.
		} else {
			backpack.add(item);
			//arraylist
			System.out.println("Wuhu! New item ahead... You added spectacular *" + item.getName() + "* into my backpack.");
			//I'm excited for the new item.
		}
		System.out.println("My backpack is " + weightCalculator() + "kg");
		//calculating the weight in my backpack.
	}

	public static void itemRemover(String itemName) {
		//method for removing item.
		boolean refund = false;
		for (Item item : backpack) {
			if (item.getName().equalsIgnoreCase(itemName)) {
				backpack.remove(item);
				refund = true;
				System.out.println("You can take your " + itemName + " back");
				//I don't like the user's item anymore... they can have them.
				break;
			}
		}
		if (!refund) {
			//kind of an error message to let the user know the item they mentioned is not on me.
			System.out.println("I don't think I have that item... Do you wanna check again?");
		}
		System.out.println("Now my backpack weights " + weightCalculator() + "kg");
		//calculating the weight in my backpack.
	}

	public static void backpack() {
		//method for showing my backpack.
		System.out.println("My backpack looks like this right now: ");
		for (Item item : backpack) {
			System.out.println(item.getName() + " - " + item.getWeight() + "kg");
		}
		System.out.println("Now my backpack weights " + weightCalculator() + "kg");
		//calculating the weight in my backpack.
	}
}